let clouds = [];
let trees = [];
let flowers = [];
let raindrops = []; // Lista de gotas de chuva

function setup() {
  createCanvas(800, 600);
  
  // Criar nuvens
  for (let i = 0; i < 5; i++) {
    clouds.push(new Cloud(random(width), random(100), random(30, 50)));
  }
  
  // Criar árvores
  for (let i = 0; i < 3; i++) {
    trees.push(new Tree(random(width), height - 100));
  }
  
  // Criar flores
  for (let i = 0; i < 5; i++) {
    flowers.push(new Flower(random(width), height - 50));
  }
}

function draw() {
  background(135, 206, 250); // Céu azul claro
  
  // Mostrar nuvens
  for (let cloud of clouds) {
    cloud.update();
    cloud.display();
  }
  
  // Mostrar árvores e flores
  for (let tree of trees) {
    tree.display();
  }
  
  for (let flower of flowers) {
    flower.display();
  }
  
  // Criar e exibir as gotas de chuva
  if (frameCount % 5 === 0) {  // A cada 5 quadros, cria uma nova gota
    raindrops.push(new Raindrop(random(width), 0));
  }
  
  // Exibir as gotas de chuva e verificar colisões com as árvores
  for (let drop of raindrops) {
    drop.update();
    drop.display();
    
    // Verificar colisão com as árvores
    for (let tree of trees) {
      if (dist(drop.x, drop.y, tree.x, tree.y - tree.height) < 50) {
        tree.water(); // A árvore cresce quando recebe água
        drop.remove(); // A gota de chuva desaparece após tocar a árvore
      }
    }
  }
}

function mousePressed() {
  // Regar flores
  for (let flower of flowers) {
    if (dist(mouseX, mouseY, flower.x, flower.y) < 50) {
      flower.water();
    }
  }
}

// Classe Nuvem
class Cloud {
  constructor(x, y, size) {
    this.x = x;
    this.y = y;
    this.size = size;
  }
  
  update() {
    this.x += random(-1, 1);
    this.y += random(-0.5, 0.5);
  }
  
  display() {
    fill(255);
    noStroke();
    ellipse(this.x, this.y, this.size, this.size / 2);
  }
}

// Classe Árvore
class Tree {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.height = 40; // Altura inicial da árvore
  }
  
  water() {
    this.height += 5; // A árvore cresce quando recebe água
  }
  
  display() {
    // Tronco
    fill(139, 69, 19);
    rect(this.x - 10, this.y - this.height, 20, this.height);
    
    // Folhas
    fill(34, 139, 34);
    ellipse(this.x, this.y - this.height - 20, 60, 60);
  }
}

// Classe Flor
class Flower {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = 10; // Tamanho inicial da flor
  }
  
  water() {
    this.size += 2; // A flor cresce quando recebe água
  }
  
  display() {
    // Pétalas
    fill(255, 0, 0);
    ellipse(this.x, this.y, this.size, this.size);
    
    // Caule
    fill(0, 255, 0);
    rect(this.x - 2, this.y, 4, 20);
  }
}

// Classe Gota de Chuva
class Raindrop {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = random(5, 10); // Tamanho aleatório da gota
    this.speed = random(4, 6); // Velocidade aleatória da queda
  }
  
  update() {
    this.y += this.speed; // A gota de chuva cai
  }
  
  display() {
    fill(0, 0, 255, 150); // Cor azul clara para a gota
    noStroke();
    ellipse(this.x, this.y, this.size, this.size * 2);
  }
  
  // Método para remover a gota quando ela tocar o solo ou a árvore
  remove() {
    let index = raindrops.indexOf(this);
    if (index > -1) {
      raindrops.splice(index, 1);
    }
  }
}